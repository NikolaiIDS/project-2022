# URP_Water
 Water shader in unity urp.

Unity 2020.3.1+

![image-Preview](Image/Preview.png)  

![image-Preview2](Image/Preview2.png)